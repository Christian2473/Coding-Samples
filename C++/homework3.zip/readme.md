# Homework 3 Programming

## Author
Christian

## Instructions
Please read through the output for all answers to your questions. They are clearly marked after red text.

## Implementation
This project includes implementations and supplementary materials for reference.
